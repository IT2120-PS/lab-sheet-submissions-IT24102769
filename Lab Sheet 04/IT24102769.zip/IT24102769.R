#Lab Exercise 4 (Descriptive Statistics)
#. Import the dataset (’Exercise.txt’) into R and store it in a data frame called ”branch data”.
setwd("C:\\Users\\it24102769\\Downloads\\IT24102769")
#Importing the data set
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",", stringsAsFactors = FALSE)

fix(data)

head(branch_data)

#2. Identify the variable type and scale of measurement for each variable.
str(branch_data)

#get the summery of the data
summary(branch_data)

#3 Obtain boxplot for sales and interpret the shape of the sales distribution.
# Boxplot for sales
boxplot(branch_data$Sales_X1, main = "Boxplot of Sales", ylab = "Sales")

#4  Calculate the five number summary and IQR for advertising variable.
# summary of the Five-number and IQR for advertising
summary(branch_data$Advertising)

# IQR
IQR(branch_data$Advertising_X2)

#5 Write an R function to find the outliers in a numeric vector and check for outliers in years variables
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- IQR(x)
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

find_outliers(branch_data$Years)